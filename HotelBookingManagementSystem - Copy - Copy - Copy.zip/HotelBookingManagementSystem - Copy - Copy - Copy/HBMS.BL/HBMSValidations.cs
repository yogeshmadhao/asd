﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.DAL;

namespace HBMS.BL
{
    public class HBMSValidations
    {

        //validation Registered user
        public static bool Validate(User u)
        {
            bool userValidated=true;
            StringBuilder message = new StringBuilder();
            
            try
            {
                if(u.UserName.Trim()==string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide your Name\n");
                }

                else if(!Regex.IsMatch(u.UserName,"[A-z]+"))
                {
                    userValidated = false;
                    message.Append("User Name should have alphabets only\n");
                }

                if(u.Role==null)
                {
                    userValidated = false;
                    message.Append("Please choose a role\n");
                }
                else
                {
                    if (u.Role !="Guest" && u.Role!="Employee")
                    {
                        userValidated = false;
                        message.Append("Please choose a valid role\n");
                    }
                }

                if(u.Password.Trim()==string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide Password\n");
                }

                if(u.Mobile.Trim()==string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide your Mobile Number\n");
                }

                else if(!Regex.IsMatch(u.Mobile,@"[789]\d{9}$"))
                {
                    userValidated = false;
                    message.Append("Mobile No should start with 7 or 8 or 9 and should contain 10 digits\n");
                }


                if (!Regex.IsMatch(u.Email, @"[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*.[a-zA-Z][a-zA-Z\.]*"))
                {
                    userValidated = false;
                    message.Append("Please enter valid Email id\n");
                }

                if (userValidated == false)
                    throw new HBMSException(message.ToString());
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }                   
           
            return userValidated;
        }

        //validate bookings entry input
        public static bool Validate(BookingDetail b,string ty)
        {
            bool bookValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if(ty.Trim()==string.Empty)
                {
                    bookValidated = false;
                    message.Append("Please select room type");
                }
                else
                {
                    if(ty!="Standard Non A/C" && ty!="Standard A/C" && ty!="Executive A/C" && ty!="Deluxe A/C")
                    {
                        bookValidated = false;
                        message.Append("Please select valid room type");
                    }
                }


                if( !(b.NoOfAdults >0))
                {
                    bookValidated = false;
                    message.Append("Please provide valid Number of Adults");
                }

                if (!(b.NoOfChildren >= 0))
                {
                    bookValidated = false;
                    message.Append("Please provide valid Number of children");
                }

                if (bookValidated == false)
                    throw new HBMSException(message.ToString());
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }      

            return bookValidated;
        }

        //validation new Hotel
        public static bool Validate(Hotel h)
        {
            bool userValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (h.HotelID.Trim() == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide hotel id\n");
                }
                else if(h.HotelID.Trim().Length >4)
                {
                    userValidated = false;
                    message.Append("Hotel ID length should be less than 5\n");
                }

                if (h.City.Trim() == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide city of the hotel\n");
                }
                else if (h.City.Trim().Length > 10)
                {
                    userValidated = false;
                    message.Append("Hotel city length should be less than 11\n");
                }

                if (h.HotelName.Trim() == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide hotel Name\n");
                }

                if (h.Address.Trim() == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide hotel addrress\n");
                }

                if (h.Description.Trim() == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide hotel description\n");
                }

                if (h.PhoneNo1.Trim() == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please provide your Mobile Number\n");
                }

                else if (!Regex.IsMatch(h.PhoneNo1, @"[789]\d{9}$"))
                {
                    userValidated = false;
                    message.Append("Mobile No should start with 7 or 8 or 9 and should contain 10 digits\n");
                }


                if (!Regex.IsMatch(h.Email, @"[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*.[a-zA-Z][a-zA-Z\.]*"))
                {
                    userValidated = false;
                    message.Append("Please enter valid Email id\n");
                }

                if (userValidated == false)
                    throw new HBMSException(message.ToString());
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidated;
        }
        
        //Add Registered User 
        public static int RegisterUser(User u)
        {
            int records = 0;

            try
            {
                if (Validate(u))
                {
                    records = HBMSOperations.RegisterUser(u);
                }
                else
                    throw new HBMSException("Please provide valid information");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        
        //Check Login 
        public static int CheckLogin(string userid, string pwd)
        {
            int status = 0;
            
            try 
            {
                status = HBMSOperations.CheckLogin(userid, pwd);
            }

            catch(HBMSException ex)
            {
                throw ex;
            }

            catch(SystemException ex)
            {
                throw ex;
            }

            return status;
        }


        //Check Availability of rooms in given hotel
        public static bool CheckAvailablility(string hotelid = "1002")
        {
            bool records = false;

            try
            {
                var hotel = HBMSOperations.CheckAvailablility();

                if (hotel != null)
                {
                    records = true;
                }
                else
                    throw new HBMSException("Rooms are not available");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Book hotel room
        public static int BookRoom(BookingDetail bd,string ty)
        {
            int records = 0;

            try
            {

                if (Validate(bd,ty))
                {
                    records = HBMSOperations.BookRoom(bd);
                }
                else
                    throw new HBMSException("Please provide valid information");
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //


        //GET LIST OF HOTEL USING LOACTION
        public static List<Hotel> SearchHotel(string loc)
        {
            List<Hotel> hotelList = null;

            try
            {
                hotelList = HBMSOperations.SearchHotel(loc);
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return hotelList;
        }


        //To get list of locations
        public static List<string> GetHotelLocations()
        {

            List<string> locList = null;

            try
            {
                locList = HBMSOperations.GetHotelLocations();
            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return locList;
        }

      //•	Performing Room Management (add/delete/modify Room fares)
        //Add room
        public static int AddRoom(RoomDetail rd)
        {
            int records = 0;

            try
            {

                records = HBMSOperations.AddRoom(rd);
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //delete room
        public static int DeleteRoom(string hotelid, int roomid)
        {
            int records = 0;

            try
            {
                records = HBMSOperations.DeleteRoom(hotelid, roomid);

            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //Modify Room
        public static int ModifyRoom(RoomDetail rd)
        {
            int records = 0;

            try
            {
                records = HBMSOperations.ModifyRoom(rd);
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Get room details
        public static List<RoomDetail> GetRoomList()
        {

            List<RoomDetail> roomList = null;

            try
            {
                roomList = HBMSOperations.GetRoomList();
            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return roomList;
        }

        //•	Performing Hotel Management (add/delete/modify Hotel info like description, any special offers etc)

        //Add Hotel
        public static int AddHotel(Hotel h)
        {
            int records = 0;

            try
            {
                records=HBMSOperations.AddHotel(h);
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Delete Hotel
        public static int DeleteHotel(string hotelid)
        {
            int records = 0;

            try
            {
                records=HBMSOperations.DeleteHotel(hotelid);
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //Modify Hotel Details
        public static int ModifyHotel(string des,string hid)
        {
            int records = 0;

            try
            {
                records=HBMSOperations.ModifyHotel(des,hid);
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


       

        public static List<Hotel> GetHotelList()
        {
            List<Hotel> hotelList = null;

            try
            {
                hotelList = HBMSOperations.GetHotelList();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return hotelList;
        }

        public static List<BookingDetail> GetBookingDetails(string hotelid)
        {
            List<BookingDetail> bdList = null;

            try
            {
                bdList = HBMSOperations.GetBookingDetails(hotelid);


            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return bdList;
        }

        public static List<User> GetGuests(string hotelid)
        {
            //Array a;
            List<User> guestList = null;

            try
            {
                guestList = HBMSOperations.GetGuests(hotelid);

            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }

        public static List<BookingDetail> GetBookingsForADate(string date)
        {

            List<BookingDetail> bdList = null;

            try
            {
                bdList = HBMSOperations.GetBookingsForADate(date);
            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return bdList;
        }
   
    }
}
