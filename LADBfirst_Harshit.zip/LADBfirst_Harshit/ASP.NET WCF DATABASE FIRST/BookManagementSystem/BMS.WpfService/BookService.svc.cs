﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data.Entity;
using BMS.Exception;


namespace BMS.WpfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class BookService : IBookService
    {
        static BookEntities context = new BookEntities();

        public  int AddBook(Books_138222 book)
        {
            int records = 0;

            try
            {
                context.Books_138222.Add(book);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public  int UpdateBook(Books_138222 book)
        {
            int records = 0;

            try
            {
                var books = (from b in context.Books_138222
                                where (b.ID == book.ID)
                                select b).FirstOrDefault();

                if (books != null)
                {
                    books.Name = book.Name;
                    books.Price = book.Price;
                    books.Description = book.Description;
                    records = context.SaveChanges();
                }
                else
                    throw new BookException("Record not found for updation");
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public  int DeleteBook(int id)
        {
            int records = 0;

            try
            {
                var books = (from b in context.Books_138222
                                where b.ID == id
                                select b).FirstOrDefault();

                if (books != null)
                {
                    context.Books_138222.Remove(books);
                    records = context.SaveChanges();
                }
                else
                    throw new BookException("Record not found for deletion");
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public  Books_138222 SearchBook(int id)
        {
            Books_138222 book = null;

            try
            {
                book = (from b in context.Books_138222
                        where b.ID == id
                        select b).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return book;
        }

        public  List<Books_138222> ShowBook()
        {
            List<Books_138222> bookList = null;

            try
            {
                bookList = context.Books_138222.ToList<Books_138222>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bookList;
        }
    }
}
