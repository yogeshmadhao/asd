﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Exception;
using BMS.DAL.BookServiceReference;

namespace BMS.DAL
{
    public class BookDAL
    {
        BookServiceClient client = new BookServiceClient();

        public int AddBookDAL(Books_138222 book)
        {
            int records = 0;
            try
            {
                records = client.AddBook(book);
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public int UpdateBookDAL(Books_138222 book)
        {
            int records = 0;
            try
            {
                records = client.UpdateBook(book);
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public  int DeleteBookDAL(int id)
        {
            int records = 0;

            try
            {
                records = client.DeleteBook(id);
            }
            catch (BookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        public  Books_138222 SearchBookDAL(int id)
        {
            Books_138222 book = null;

            try
            {
                book = client.SearchBook(id);
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return book;
        
        }

        public List<Books_138222> ShowBookDAL()
        {
            List<Books_138222> bookList = null;

            try
            {
                bookList = client.ShowBook().ToList() ;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bookList;
        }


    }
}
