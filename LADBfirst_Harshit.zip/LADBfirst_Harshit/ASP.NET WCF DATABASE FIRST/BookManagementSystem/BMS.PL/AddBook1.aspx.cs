﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BMS.BL;
using BMS.DAL.BookServiceReference;

namespace BMS.PL
{
    public partial class AddBook1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btnAddBook_Click(object sender, EventArgs e)
        {
            try
            {
                Books_138222 book = new Books_138222();

                book.ID = Convert.ToInt32(txtID.Text);
                book.Name = txtName.Text;
                book.Price = Convert.ToDecimal(txtPrice.Text);
                book.Description = txtDescription.Text;

                int status = BookBLL.AddBookBLL(book);

                if (status > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "m1", "alert('Book Details Added')", true);

                    txtID.Text = "";
                    txtName.Text = "";
                    txtDescription.Text = "";
                    txtPrice.Text = "";
                }
            }
            catch (SystemException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "error5", "alert('" + ex.Message + "')", true);
            }
        }
    }
}