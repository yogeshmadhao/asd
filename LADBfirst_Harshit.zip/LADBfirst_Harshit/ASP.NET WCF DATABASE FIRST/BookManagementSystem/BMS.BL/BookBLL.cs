﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Exception;
using BMS.DAL;
using BMS.DAL.BookServiceReference;


namespace BMS.BL
{
    public class BookBLL
    {
        public static bool ValidateBook(Books_138222 book)
        {
            bool result = true;
            StringBuilder sb = new StringBuilder();

            if (book.ID <= 0 || book.ID == null)
            {
                result = false;
                sb.Append("ID cannot be blank or negative");
            }

            if (book.Name == string.Empty)
            {
                result = false;
                sb.Append("Book Name cannot be blank");
            }

            if (book.Description == string.Empty)
            {
                result = false;
                sb.Append("Description cannot be blank");
            }
            if (book.Price <= 0 || book.Price == null)
            {
                result = false;
                sb.Append("Price cannot be negative or zero");
            }

            if (result == false)
            {
                throw new BookException(sb.ToString());
            }
            return result;
        }

        public static int AddBookBLL(Books_138222 book)
        {
            int records = 0;
            try
            {
                if (ValidateBook(book))
                {
                    BookDAL obj = new BookDAL();
                    records = obj.AddBookDAL(book);
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }


            return records;
        }

        public static List<Books_138222> ShowBookBLL()
        {
            List<Books_138222> booklist = null;

            try
            {
                BookDAL bmsdal = new BookDAL();
                booklist = bmsdal.ShowBookDAL();
            }
            catch (BookException ex)
            {
                throw ex;
            }

            return booklist;
        }

        public static Books_138222 SearchBookBLL(int id)
        {
            Books_138222 book = null;
            try
            {
                BookDAL bmsdal = new BookDAL();
                book = bmsdal.SearchBookDAL(id);
            }
            catch (BookException ex)
            {
                throw ex;
            }

            return book;
        }

        public static int UpdateBookBLL(Books_138222 book)
        {
            int records = 0;
            try
            {
                if (ValidateBook(book))
                {
                    BookDAL bmsdal = new BookDAL();
                    records = bmsdal.UpdateBookDAL(book);
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }
            return records;
        }

        public static int DeleteBookBLL(int id)
        {
            int records = 0;

            try
            {
                if (id > 0)
                {
                    BookDAL bmsdal = new BookDAL();
                    records = bmsdal.DeleteBookDAL(id);
                }
                else
                {
                    throw new BookException("Invalid Book ID");
                }
            }
            catch (BookException ex)
            {
                throw ex;
            }

            return records;
        }
    }
}
