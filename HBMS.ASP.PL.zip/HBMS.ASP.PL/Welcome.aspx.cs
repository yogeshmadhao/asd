﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL
{
    public partial class Welcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string loc = Session["loc"].ToString();
            grdHotellist.DataSource = HBMSValidations.SearchHotel(loc);
            grdHotellist.DataBind();
            lblLoc.Text = "Hotels in " + loc;
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["loc"] = DropDownList2.SelectedValue;
        }

        protected void btnchngLoc_Click(object sender, EventArgs e)
        {
            DropDownList2.Visible = true;
            btnShow.Visible = true;
            DropDownList2.DataSource = HBMSValidations.GetHotelLocations();
            DropDownList2.DataBind();
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            string loc = DropDownList2.SelectedValue.ToString();
            grdHotellist.DataSource = HBMSValidations.SearchHotel(loc);
            grdHotellist.DataBind();
            DropDownList2.Visible = false;
            btnShow.Visible = false;
            lblLoc.Text = "Hotels in " + loc;
        }

      
    }
}