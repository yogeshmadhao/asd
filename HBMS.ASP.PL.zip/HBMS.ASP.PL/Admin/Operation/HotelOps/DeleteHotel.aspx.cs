﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.BL;
using HBMS.Entity;
using HBMS.Exception;

namespace HBMS.ASP.PL.Admin.Operation.HotelOps
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtID.Text = Session["Hid"].ToString();
        }

        protected void btnDeleteHotel_Click(object sender, EventArgs e)
        {
            try
            {
                int count = HBMSValidations.DeleteHotel(txtID.Text);

                if (count > 0)
                {

                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Hotel Deleted Successfully')", true);
                    
                }
            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert(" + ex.Message + ")", true);

            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert(" + ex.Message + ")", true);
            }
        }
    }
}