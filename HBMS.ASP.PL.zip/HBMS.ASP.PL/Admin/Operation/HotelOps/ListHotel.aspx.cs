﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.BL;
using HBMS.Entity;
using HBMS.Exception;

namespace HBMS.ASP.PL.Admin.Operation.HotelOps
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //listBox_ListHotel.DataSource = HBMSValidations.GetHotelList();
            //listBox_ListHotel.DataBind();

            grid_ListHotel.DataSource = HBMSValidations.GetHotelList();
            grid_ListHotel.DataBind();
        }

        protected void grid_ListHotel_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Session["Hid"] = e.CommandArgument.ToString();
            
            if (e.CommandName == "Modify")
            {

                Response.Redirect("ModifyDescription.aspx");
            }

            else if (e.CommandName == "Delete")
            {
                Response.Redirect("DeleteHotel.aspx");
            }
        }
    }
}