﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Admin.Operation.Room
{
    public partial class Add_Room : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HotelDropDownList.DataSource = HBMSValidations.GetHotelList();
            HotelDropDownList.DataTextField = "HotelName";
            HotelDropDownList.DataValueField = "HotelID";
            HotelDropDownList.DataBind();

            RoomTypeDropDownList.DataSource = new string[] { "Standard Non A/C", "Standard A/C", "Executive A/C", "Deluxe A/C" };
            RoomTypeDropDownList.DataBind();
        }

        protected void btnAddRoom_Click(object sender, EventArgs e)
        {
            RoomDetail rd = new RoomDetail();
            try
            {
                rd.HotelID = HotelDropDownList.SelectedValue;
                rd.PerNightRate = Convert.ToInt32(txtRoomFare.Text);
                rd.RoomNo = txtRoomNo.Text;
                rd.RoomType = RoomTypeDropDownList.SelectedValue;

                int records = 0;

                records = HBMSValidations.AddRoom(rd);

                if (records > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "m1", "alert('Room Details Added')", true);

                    txtRoomFare.Text = "";
                    txtRoomNo.Text = "";
                    HotelDropDownList.SelectedIndex = 0;
                    RoomTypeDropDownList.SelectedIndex = 0;
                }

                else
                    throw new HBMSException("Room Details not Added");


            }

            catch(HBMSException ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "error5", "alert('" + ex.Message + "')", true);
            }
        }
    }
}