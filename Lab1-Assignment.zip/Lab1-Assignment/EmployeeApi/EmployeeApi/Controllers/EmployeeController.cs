﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmployeeApi.Models;

namespace EmployeeApi.Controllers
{
    public class EmployeeController : ApiController
    {

        public IHttpActionResult GetEmployee()
        {
            return Ok(EmployeeContext.EmpList);

        }

        public IHttpActionResult GetEmployee(int id)
        {
            Employee emp = EmployeeContext.EmpList.FirstOrDefault(e => e.EmployeeID == id);
            if (emp == null)
                return NotFound();
            else
                return Ok(emp);
        }

        public IHttpActionResult GetEmployee(string gd)
        {
            Employee emp = EmployeeContext.EmpList.FirstOrDefault(e => e.Grade == gd);
            if (emp == null)
                return NotFound();
            else
                return Ok(emp);

        }

        public HttpResponseMessage Post(Employee emp)
        {
            try
            {
                EmployeeContext.EmpList.Add(emp);
                var msg = Request.CreateResponse(HttpStatusCode.OK);
                //msg.Headers.Location = new Uri(Request.RequestUri + emp.EmployeeID.ToString());
                return msg;
            }

            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        public HttpResponseMessage Delete(int id)
        {
            Employee emp = EmployeeContext.EmpList.FirstOrDefault(e => e.EmployeeID == id);
            if (emp == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Record with id:" + id + "not found");

            }
            else
            {
                EmployeeContext.EmpList.Remove(emp);
                return Request.CreateResponse(HttpStatusCode.OK);
            }

        }

    }
}
