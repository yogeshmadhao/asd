﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeApi.Models
{
    public class EmployeeContext
    {
         public static List<Employee> EmpList = new List<Employee>()
        {
            new Employee() {EmployeeID=138222,FirstName="Harshit",LastName="Khandelwal", DOB=new DateTime(1994,11,21), Email="harsh5x4@gmail.com", Grade="A5",Contact="9441770864"},
            new Employee() {EmployeeID=138223,FirstName="Nikita",LastName="Gupta", DOB=new DateTime(1994,12,2), Email="nikita5x4@gmail.com", Grade="A4",Contact="9441770863"}
        };
    }
}